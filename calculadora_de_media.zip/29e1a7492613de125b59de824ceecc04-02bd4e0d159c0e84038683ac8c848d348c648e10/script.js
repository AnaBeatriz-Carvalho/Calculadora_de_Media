var nome = "Guilherme";
var notaDoPrimeiroBimestre = 9;
var notaDoSegundoBimestre = 7;
var notaDoTerceiroBimestre = 4;
var notaDoQuartoBimestre = 2;

var notaFinal = (notaDoPrimeiroBimestre + notaDoSegundoBimestre + notaDoTerceiroBimestre + notaDoQuartoBimestre) / 4;

var notaFixada = notaFinal.toFixed(1); //toFixed(0) arredonda

console.log("Bem vindo " + nome);
console.log(notaFixada);

//Revisão
//Variáveis, Strings, console.log, toFixed, operações matemáticas, concatenação
//Desafios - Aula 01
//-Conversor de temperatura fahrenheit e celsius V
//-Verificação se passou de ano ou não V
//-Mudar fundo da imagem V
//-Conversor de moedas V
//-Colocar a conta inteira da média em apenas uma linha
//-Mudar cor de fundo V
console.log("Conversor de Temperatura: Fahrenheit e Celsius");
var tempCelsius = 20;
var converterF = (tempCelsius * 1.8) + 32;
console.log(converterF + " F");

console.log("Verificar se passou de ano ou não");
var nota1 = 9;
var nota2 = 6;
var nota3 = 7;
var nota4 = 6;

var media = (nota1 + nota2 + nota3 + nota4) / 4;

console.log("A sua média é " +media);
if (media < 6){
    console.log("Você foi reprovado!");
}
else{
    console.log("Você foi aprovado!");
}

console.log("Conversor de Moedas");
var dolar = 50;

var converterReal = dolar * 5.44;

console.log("A conversão é de R$ " + converterReal + " reais");